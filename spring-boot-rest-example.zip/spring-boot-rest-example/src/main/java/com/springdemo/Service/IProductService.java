package com.springdemo.Service;
import com.springdemo.Model.Product;

import java.util.List;
public interface IProductService 
{
List<Product> findAll();
}
